import { Grid } from './core/grid';
import { updateGrid } from './core/engine';
import { Renderer } from './renderer/renderer';
import { setupInput } from './input/input';

declare global {
  interface Window {
    drawIfMouseHeld: (grid: Grid, renderer: Renderer) => boolean;
  }
}

const GRID_WIDTH = 300;
const GRID_HEIGHT = 200;
let scale = 2;

const canvas = document.querySelector('canvas')!;
const grid = new Grid(GRID_WIDTH, GRID_HEIGHT);
const renderer = new Renderer(canvas, scale);

function gameLoop() {
  window.drawIfMouseHeld(grid, renderer);
  updateGrid(grid);
  renderer.draw(grid);
  requestAnimationFrame(gameLoop);
}

function setAppScale(newScale: number) {
  scale = newScale;
  renderer.setScale(scale);
  renderer.resizeCanvas(GRID_WIDTH, GRID_HEIGHT);
}

setupInput(canvas, grid, renderer);

document.getElementById('scale1')?.addEventListener('click', () => {
  setAppScale(1);
});
document.getElementById('scale2')?.addEventListener('click', () => {
  setAppScale(2);
});
document.getElementById('scale4')?.addEventListener('click', () => {
  setAppScale(4);
});

renderer.resizeCanvas(GRID_WIDTH, GRID_HEIGHT);
renderer.draw(grid);

requestAnimationFrame(gameLoop);
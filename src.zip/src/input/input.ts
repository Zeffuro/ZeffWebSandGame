import type { Grid } from '../core/grid';
import type { Renderer } from '../renderer/renderer';
import { ParticleTypes } from '../core/particle';

// Add these variables outside (above) the setupInput function
let lastMouseGridX: number | null = null;
let lastMouseGridY: number | null = null;
let currentParticleType: ParticleTypes = ParticleTypes.Sand;

export function setupInput(canvas: HTMLCanvasElement, grid: Grid, renderer: Renderer) {
  let isDrawing = false;

  function updateMouseGridPosition(e: MouseEvent) {
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    lastMouseGridX = Math.floor(mouseX / renderer.scale);
    lastMouseGridY = Math.floor(mouseY / renderer.scale);
  }

  canvas.addEventListener('mousedown', (e) => {
    isDrawing = true;
    updateMouseGridPosition(e);
    if (lastMouseGridX !== null && lastMouseGridY !== null) {
        grid.set(lastMouseGridX, lastMouseGridY, currentParticleType);
    }
  });

  canvas.addEventListener('mouseup', () => {
    isDrawing = false;
    lastMouseGridX = null;
    lastMouseGridY = null;
  });

  canvas.addEventListener('mouseleave', () => {
    isDrawing = false;
    lastMouseGridX = null;
    lastMouseGridY = null;
  });

  canvas.addEventListener('mousemove', (e) => {
    if (isDrawing) {
      updateMouseGridPosition(e); // Replace paint(e)
      if (lastMouseGridX !== null && lastMouseGridY !== null) { // Add this line
        grid.set(lastMouseGridX, lastMouseGridY, currentParticleType); // Add this line
      } // Add this line
    }
  });

  (window as any).drawIfMouseHeld = function(gridInstance: Grid, rendererInstance: Renderer) {
    if (isDrawing && lastMouseGridX !== null && lastMouseGridY !== null) {
      if (
        lastMouseGridX >= 0 && lastMouseGridX < gridInstance.width &&
        lastMouseGridY >= 0 && lastMouseGridY < gridInstance.height
      ){
        gridInstance.set(lastMouseGridX, lastMouseGridY, currentParticleType);
        return true;
      }
    }
    return false;
  };
}
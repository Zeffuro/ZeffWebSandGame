import { ParticleTypes, type ParticleType } from "./particle";

export class Grid {
  width: number;
  height: number;
  data: Uint8Array;

  constructor(width: number, height: number) {
    this.width = width;
    this.height = height;
    this.data = new Uint8Array(width * height);
    // Initialize to empty
    this.data.fill(ParticleTypes.Empty);
  }

  getIndex(x: number, y: number) {
    return y * this.width + x;
  }

  get(x: number, y: number): ParticleType | null {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) return null;
    return this.data[this.getIndex(x, y)] as ParticleType;
  }

  set(x: number, y: number, type: ParticleType) {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) return;
    this.data[this.getIndex(x, y)] = type;
  }

  swap(x1: number, y1: number, x2: number, y2: number) {
    const idx1 = this.getIndex(x1, y1);
    const idx2 = this.getIndex(x2, y2);
    const temp = this.data[idx1];
    this.data[idx1] = this.data[idx2];
    this.data[idx2] = temp;
  }
}
export const ParticleTypes = {
  Empty: 0,
  Sand: 1,
} as const;

export type ParticleType = typeof ParticleTypes[keyof typeof ParticleTypes];

// Color lookup by particle ID:
export const COLORS: Record<ParticleType, [number, number, number]> = {
  [ParticleTypes.Empty]: [0, 0, 0],
  [ParticleTypes.Sand]: [194, 178, 128],
};
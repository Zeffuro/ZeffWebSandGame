import { Grid } from './grid';
import { ParticleTypes } from './particle';

export function updateGrid(grid: Grid) {
  for (let y = grid.height - 2; y >= 0; y--) {
    for (let x = 0; x < grid.width; x++) {
      const current = grid.get(x, y);
      if (!current || current !== ParticleTypes.Sand) continue;

      // Check if the cell below is empty
      if (grid.get(x, y + 1) === ParticleTypes.Empty) {
        grid.swap(x, y, x, y + 1);
      } 
      // Check if the bottom-left cell is empty
      else if (grid.get(x - 1, y + 1) === ParticleTypes.Empty) {
        grid.swap(x, y, x - 1, y + 1);
      } 
      // Check if the bottom-right cell is empty
      else if (grid.get(x + 1, y + 1) === ParticleTypes.Empty) {
        grid.swap(x, y, x + 1, y + 1);
      }
    }
  }
}